package com.food.swigato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwigatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwigatoApplication.class, args);
	}

}
