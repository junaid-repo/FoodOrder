package com.food.swigato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwigatoApplicationTests {

	@Test
	void contextLoads() {
	}

}
